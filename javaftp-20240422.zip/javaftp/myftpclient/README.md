create the JAR with 

mvn clean compile assembly:single

and run it with

java -jar .\target\myftpclient-1-jar-with-dependencies.jar